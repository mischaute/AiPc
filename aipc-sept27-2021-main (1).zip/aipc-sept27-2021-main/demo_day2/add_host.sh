
ssh-keyscan -H 209.97.166.218 >> ~/.ssh/known_hosts
